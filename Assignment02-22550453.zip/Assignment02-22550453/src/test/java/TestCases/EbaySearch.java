package TestCases;

import Base.BaseTest;
import Pages.Homepage;
import Pages.ProductPage;
import Pages.SearchResult;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class EbaySearchAddToCart extends BaseTest {

    @BeforeTest
    public void setup() {
        setUpBrowser();
    }

    @Test
    public void searchAndBuySamsungPhone() {

        Homepage homePage = new Homepage(driver);
        SearchResult searchResultsPage = new SearchResult(driver);
        ProductPage productPage = new ProductPage(driver);


    }

}
