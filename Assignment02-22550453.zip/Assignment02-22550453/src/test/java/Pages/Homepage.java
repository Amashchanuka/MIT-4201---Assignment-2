package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;


@Test
public class Homepage {
    WebDriver driver = new ChromeDriver();

    driver.get("https://www.ebay.com/");
    driver.manage().window().maximize();

    //driver.findElement(By.xpath("//input[@id='gh-ac'"))
    driver.findElement(By.xpath("//input[@id='gh-ac']")).sendKeys("camera digital");
    WebElement dropdown = driver.findElement(By.xpath("//select[@id='gh-ac']"));
    Select select = new Select(dropdown);
        select.selectByVisibleText("Cameras & Photo");

        driver.findElement(By.xpath("//input[@id='gh-btn']")).click();

        driver.findElement(By.xpath("//span[text()='Apple']")).click();

    Actions actions = new Actions(driver);
        actions.scrollByAmount(0,600).perform();

        driver.quit();
    //new Actions(driver).scrollByAmount(0,300)

    //new Select(findElement(By.xpath("//input[@id='gh-ac']")))

    // Locators using @FindBy
    @FindBy(id = "gh-ac") // Search input field
            WebElement searchBox;

    @FindBy(id = "gh-btn") // Search button
    WebElement searchButton;

    // Constructor to initialize elements
    public Homepage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Method to searchFor
    public void searchFor(String keyword) {
        searchBox.sendKeys(keyword);
        searchButton.click();
    }
}
